package apap.tutorial.pergipergi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PergipergiApplicationTests {

	@Test
	void contextLoads() {
	}

}
