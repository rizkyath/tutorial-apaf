package apap.tutorial.pergipergi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PergipergiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PergipergiApplication.class, args);
	}

}
